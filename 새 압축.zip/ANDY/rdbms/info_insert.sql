insert into 
  andy.ANDY_INFORMATION (
    ID, 
    IMAGE, 
    NAME, 
    AGE, 
    POSITION
  )
values
  (
    $ID, 
    $IMAGE, 
    $NAME, 
    $AGE, 
    $POSITION
  );